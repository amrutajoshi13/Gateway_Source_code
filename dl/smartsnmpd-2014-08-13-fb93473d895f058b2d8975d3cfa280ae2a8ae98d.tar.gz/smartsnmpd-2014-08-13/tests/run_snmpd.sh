LUA_PATH="lualib/?/init.lua;lualib/?.lua;./?.lua" LUA_CPATH="build/?.so" ./bin/smartsnmpd -c config/smartsnmp.conf
