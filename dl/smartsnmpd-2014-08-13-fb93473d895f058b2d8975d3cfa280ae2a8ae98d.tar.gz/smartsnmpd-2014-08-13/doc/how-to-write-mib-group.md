How to write MIB Group for SmartSNMP

*TO BE WRITTEN*
