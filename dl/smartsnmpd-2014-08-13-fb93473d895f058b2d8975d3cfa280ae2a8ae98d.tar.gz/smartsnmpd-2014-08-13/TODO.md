# TODO

- Installing script.
- Run as a deamon.
- Better configuration.
- Run as a sub-agent of Net-SNMP Agent through Agent-X protocol.
